package com.shine.model.vo;

import lombok.Data;

@Data
public class RegionStockVO {
    private Integer rid;
    private String name;
    private Integer amount;
}
