package com.shine.model.vo;

import lombok.Data;

@Data
public class AnalysisVO {
    String name;
    Integer amount;
}
