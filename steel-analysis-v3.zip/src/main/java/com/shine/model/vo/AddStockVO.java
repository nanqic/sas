package com.shine.model.vo;

import lombok.Data;

@Data
public class AddStockVO {
    private Integer pid;
    private Integer amount;
    private Byte rid;
}
